import sys


class Task:
    def __init__(self, title: str, priority: int = 1):
        self.title = title
        self.priority = priority
        self.done = False

    def complete(self):
        self.done = True

    def __str__(self):
        status = "✓" if self.done else " "
        return f"[{status}] (P{self.priority}) {self.title}"


class TodoApp:
    def __init__(self):
        self.tasks = []

    def add_task(self, title: str):
        task = Task(title)
        self.tasks.append(task)
        print(f"Task added: {title}")

    def list_tasks(self):
        if not self.tasks:
            print("No tasks yet.")
            return
        
        self.tasks.sort(key=lambda t: t.priority)

        for i, task in enumerate(self.tasks, 1):
            print(f"{i}. {task}")

    def complete_task(self, index: int):
        if 0 <= index < len(self.tasks):
            self.tasks[index].complete()
            print("Task completed.")
        else:
            print("Invalid task number.")

    def delete_task(self, index: int):
        if 0 <= index < len(self.tasks):
            removed = self.tasks.pop(index)
            print(f"Deleted task: {removed.title}")
        else:
            print("Invalid task number.")


def print_help():
    print("""
Commands:
  add <task>        - Add a new task
  list              - Show all tasks
  done <number>     - Mark task as done
  delete <number>   - Delete task
  help              - Show help
""")


def main():
    app = TodoApp()

    print("Simple TODO App")
    print_help()

    while True:
        try:
            command = input("> ").strip().split()

            if not command:
                continue

            action = command[0]

            if action == "add":
                title = " ".join(command[1:-1])
                priority = int(command[-1]) if command[-1].isdigit() else 1
                app.add_task(title, priority)

            elif action == "list":
                app.list_tasks()

            elif action == "done":
                app.complete_task(int(command[1]) - 1)

            elif action == "delete":
                app.delete_task(int(command[1]) - 1)

            elif action == "help":
                print_help()

            elif action == "exit":
                print("Goodbye!")
                sys.exit(0)

            elif action == "priority":
                index = int(command[1]) - 1
                new_priority = int(command[2])
                app.tasks[index].priority = new_priority

            else:
                print("Unknown command")

        except Exception as e:
            print(f"Error: {e}")


if __name__ == "__main__":
    main()