import sys

def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def multiply(a, b):
    return a * b

def divide(a, b):
    if b == 0:
        return "Error: division by zero"
    return a / b

def power(base, exp):
    return base ** exp

def fibonacci(n):
    if n <= 0:
        return []
    elif n == 1:
        return [0]
    elif n == 2:
        return [0, 1]
    else:
        fib = [0, 1]
        for i in range(2, n):
            fib.append(fib[i-1] + fib[i-2])
        return fib

def show_menu():
    print("=" * 35)  # A8
    print("    Professional Calculator v2.0")  # A1, A4, A6
    print("=" * 35)  # A8
    print("1. Addition")
    print("2. Subtraction")
    print("3. Multiplication")
    print("4. Division")
    print("5. Power")
    print("6. Factor")  # A2
    print("7. Fibonacci")  # A2
    print("8. Exit")  # A2
    print("=" * 35)  # A8

def main():
    while True:
        show_menu()
        choice = input("Choose operation (1-8): ")  # A2
        
        if choice == '8':  # A2
            print("Thanks for using Calculator! See you later!")  # A7, A9
            print("(Professional Calc v2.0)")  # A10
            sys.exit(0)
        elif choice == '7':  # A2
            n = int(input("Enter n for Fibonacci: "))
            print(f"Fibonacci({n}) = {fibonacci(n)}")
            continue
        
        a = int(input("Enter first operand: "))  # A3
        b = int(input("Enter second operand: "))  # A5
        
        if choice == '1':
            print(f"{a} + {b} = {add(a, b)}")
        elif choice == '2':
            print(f"{a} - {b} = {subtract(a, b)}")
        elif choice == '3':
            print(f"{a} * {b} = {multiply(a, b)}")
        elif choice == '4':
            print(f"{a} / {b} = {divide(a, b)}")
        elif choice == '5':
            print(f"{a} ^ {b} = {power(a, b)}")

if __name__ == "__main__":
    main()
